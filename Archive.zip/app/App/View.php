<?php

namespace NextG\Autoreply\App;

class View
{
}
