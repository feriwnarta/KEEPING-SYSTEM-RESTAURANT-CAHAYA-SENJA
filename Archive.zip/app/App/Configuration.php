<?php 

namespace NextG\Autoreply\App;

class Configuration {
    public static $DB_HOST = 'localhost';
    public static $DB_USER = 'root';
    public static $DB_NAME = 'autoreply_senja';
    public static $DB_PASS = '';

    public static $ROOT = 'http://localhost/autoreply/';
}